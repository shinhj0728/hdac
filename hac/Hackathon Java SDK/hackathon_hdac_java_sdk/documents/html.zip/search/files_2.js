var searchData=
[
  ['permissions_2ejava',['Permissions.java',['../_permissions_8java.html',1,'']]]
];
