var searchData=
[
  ['unreadablewalletexception',['UnreadableWalletException',['../classcom_1_1hdac_sdk_1_1hdac_wallet_1_1_unreadable_wallet_exception.html#a8a6d8faf85ecc9e93a98c7008993cbd4',1,'com.hdacSdk.hdacWallet.UnreadableWalletException.UnreadableWalletException(String s)'],['../classcom_1_1hdac_sdk_1_1hdac_wallet_1_1_unreadable_wallet_exception.html#a2eaf6425d5751df4e41b72a3af6e0391',1,'com.hdacSdk.hdacWallet.UnreadableWalletException.UnreadableWalletException(String s, Throwable t)']]],
  ['unsubscribe',['unsubscribe',['../classcom_1_1hdac_sdk_1_1hdac_core_api_1_1_hdac_command.html#abcdeb4ace92643cebe29eab767a980dc',1,'com::hdacSdk::hdacCoreApi::HdacCommand']]]
];
