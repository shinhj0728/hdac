var searchData=
[
  ['validateaddress',['validateaddress',['../classcom_1_1hdac_sdk_1_1hdac_core_api_1_1_hdac_command.html#a9fb1559d57578a5d276dd4853a581704',1,'com::hdacSdk::hdacCoreApi::HdacCommand']]],
  ['verifymessage',['verifymessage',['../classcom_1_1hdac_sdk_1_1hdac_core_api_1_1_hdac_command.html#afff0254b6cef18a8a325531ca02ec1f6',1,'com::hdacSdk::hdacCoreApi::HdacCommand']]]
];
