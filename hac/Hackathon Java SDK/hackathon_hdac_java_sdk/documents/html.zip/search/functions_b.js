var searchData=
[
  ['newrpcclient',['newRPCClient',['../classcom_1_1hdac_sdk_1_1hdac_core_api_1_1_hdac_api_manager.html#a44bfaa39d563551b4eca924573d140cc',1,'com::hdacSdk::hdacCoreApi::HdacApiManager']]]
];
