var searchData=
[
  ['permissions',['Permissions',['../classcom_1_1hdac_sdk_1_1hdac_core_api_1_1_permissions.html',1,'com::hdacSdk::hdacCoreApi']]]
];
